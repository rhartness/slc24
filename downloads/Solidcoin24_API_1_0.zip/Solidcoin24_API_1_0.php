<?php
// Solidcoin24 API PHP wrapper class, version 1.0

class Solidcoin24_API {

	private $idString, $password, $hasUserdata, $lastError;
	
	function __construct($idString=0, $password=0) {
		if ($idString && $password) {
			$this->idString = $idString;
			$this->password = $password;
			$this->hasUserdata = true;
		} else {
			$this->hasUserdata = false;
		}
	}
	
	function getTicker($currency="btc") {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("exchange/ticker/$currency", array(), true);
		
		if (!isset($r->error)) {
			return $r;
		} else {
			$lastError = $r->average;
			return false;
		}
	}
	
	function getBalance($currency="slc") {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("balance/$currency", array(), true);
		
		if (!isset($r->error)) {
			return $r->balance;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function transferToUser($recipient, $amount, $currency="slc") {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("internal_transfer/$currency", array("r" => $recipient, "am" => $amount), true);
		
		if (!isset($r->error)) {
			return true;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function isSolidcoin24Address($address, $currency="slc") {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("internal_transfer/check_address/$currency", array("a" => $address), true);
		
		if (!isset($r->error)) {
			return $r->hash;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function createDepositAddress($group="") {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("transfer/deposit/new", array("g" => $group), true);
		
		if (!isset($r->error)) {
			return $r->address;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function checkDepositAddress($address) {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("transfer/deposit/info", array("a" => $address), true);
		
		if (!isset($r->error)) {
			return $r;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function checkDepositAddressesByGroup($group) {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("transfer/deposit/info", array("g" => $group), true);
		
		if (!isset($r->error)) {
			return $r;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	function withdrawTo($address, $amount) {
		if (!$this->hasUserdata) { $lastError = "Please specify userdata."; return false; }
		
		$r = $this->apiCall("transfer/withdrawal/withdraw", array("a" => $address, "am" => $amount), true);
		
		if (!isset($r->error)) {
			return $r;
		} else {
			$this->lastError = $r->error;
			return false;
		}
	}
	
	private function getUserdataBase64() {
		if ($this->hasUserdata) {
			return base64_encode($this->idString.":".$this->password);
		}
	}
	
	public function getLastError() {
		return $this->lastError;
	}
	
	public function apiCall($call, $get=array(), $authenticate=false) {
		if ($authenticate) {
			$url = "https://slc24.com/api/".$this->getUserdataBase64()."/$call";
		} else {
			$url = "https://slc24.com/api/$call";
		}
		
		if (function_exists("HttpRequest")) {
			$r = new HttpRequest($url, HttpRequest::METH_GET);
			$r->addQueryData($get);
			try {
				$r->send();
				if ($r->getResponseCode() == 200) {
					return json_decode($r->getResponseBody());
				}
			} catch (HttpException $ex) {
				return false;
			}
		}
		
		if (function_exists("curl_init")) {
			$url .= "?";
		
			foreach ($get as $key => $value) {
				$url .= "$key=".urlencode($value)."&";
			}
		
			$ch = curl_init();
		
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

			$response = curl_exec($ch);
			
			curl_close($ch);
			
			return json_decode($response);
		}
		
		return false;
	}

}

?>